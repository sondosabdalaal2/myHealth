import 'package:flutter/material.dart';
import 'rounded_button.dart';

class AnimationPage extends StatelessWidget {
  final String text;
  final Widget page;
  final Color buttonColor;
  final Color textColor;

  AnimationPage({@required this.text,@required this.page,@required this.buttonColor,this.textColor});

  @override
  Widget build(BuildContext context) {
    return RoundedButton(
      text: text,
      press: () {
        Navigator.push(
          context,
          PageRouteBuilder(
            transitionDuration: Duration(seconds: 1),
            transitionsBuilder: (BuildContext context,
                Animation<double> animation,
                Animation<double> secAnimation,
                Widget child) {
              animation= CurvedAnimation(parent: animation, curve: Curves.easeIn);
              return ScaleTransition(
                scale: animation,
                child: child,
                alignment: Alignment.center,
              );
            },
            pageBuilder: (BuildContext context,
                Animation<double> animation,
                Animation<double> secAnimation) {
              return page;
            },
          ),
          // MaterialPageRoute(
          //
          //
          //   builder: (context) {
          //     return LoginScreen();
          //   },
          // ),
        );
      },
      color: buttonColor,
      textColor: textColor,
    );
  }
}
