import 'package:flutter/material.dart';
import 'components/body.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DoctorMainPage extends StatefulWidget {
  @override
  _DoctorMainPageState createState() => _DoctorMainPageState();
}

class _DoctorMainPageState extends State<DoctorMainPage> {
  final _auth= FirebaseAuth.instance;
  final _firestore= FirebaseFirestore.instance;
  String currentUser, name, e, bd, ph,id;

  User loggedInUser;

  void getUserData(var user) async {

      final fullName = user.data()['fullName'].toString();
      final email = user.data()['email'].toString();
      final birthdate = user.data()['birthdate'].toString();
      final phone = user.data()['phone'].toString();
      final ID = user.data()['ID'].toString();
      final userID=user.data()['uid'].toString();
      currentUser = loggedInUser.uid;
      if (userID == currentUser) {
        setState(() {
          name = '$fullName';
          e = '$email';
          bd = '$birthdate';
          ph = '$phone';
          id = '$ID';
        });

    }
  }
  void doctorsStream()async{
    await for(var snapshot in _firestore.collection('Doctors').snapshots()){
      for( var user in snapshot.docs){
        getUserData(user);
      }
    }
  }

  @override
  void initState() {
    getCurrentUser();
    doctorsStream();
    super.initState();
  }

  void getCurrentUser() async{
    try{
      final user= await _auth.currentUser;
      if(user!=null){
        loggedInUser=user;
      //  print(loggedInUser.email);
      //  print(loggedInUser.uid);
      }
    }catch(e){
      print(e);
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(name: name,email: e,phone: ph,ID: id,birth: bd,),
    );
  }
}