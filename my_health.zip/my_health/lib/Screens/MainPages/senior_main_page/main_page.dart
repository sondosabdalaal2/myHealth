import 'package:flutter/material.dart';
import 'components/body.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ManagerMainPage extends StatefulWidget {
  @override
  _ManagerMainPageState createState() => _ManagerMainPageState();
}

class _ManagerMainPageState extends State<ManagerMainPage> {
  final _auth= FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;
  String currentUser,name,e,userid;

  User loggedInUser;
  void getUserData(var user) async {
      final fullName = user.data()['fullName'].toString();
      final email = user.data()['email'].toString();
      final uid = user.data()['uid'].toString();
      currentUser = loggedInUser.uid;
      if (uid == currentUser) {
        setState(() {
          name = '$fullName';
          e = '$email';
          userid='$uid';

        });

    }
  }
  void managerStream()async{
    await for(var snapshot in _firestore.collection('Manager').snapshots()){
      for( var user in snapshot.docs){
        getUserData(user);
      }
    }
  }

  @override
  void initState() {
    getCurrentUser();
    managerStream();
    super.initState();
  }

  void getCurrentUser() async{
    try{
      final user= await _auth.currentUser;
      if(user!=null){
        loggedInUser=user;
//        print(loggedInUser.email);
      }
    }catch(e){
      print(e);
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(name: name,email: e,),
    );
  }
}