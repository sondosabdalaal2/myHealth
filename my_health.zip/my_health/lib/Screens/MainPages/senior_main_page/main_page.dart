import 'package:flutter/material.dart';
import 'components/body.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ManagerMainPage extends StatefulWidget {
  @override
  _ManagerMainPageState createState() => _ManagerMainPageState();
}

class _ManagerMainPageState extends State<ManagerMainPage> {
  final _auth= FirebaseAuth.instance;

  User loggedInUser;

  @override
  void initState() {
    getCurrentUser();
    super.initState();
  }

  void getCurrentUser() async{
    try{
      final user= await _auth.currentUser;
      if(user!=null){
        loggedInUser=user;
        print(loggedInUser.email);
      }
    }catch(e){
      print(e);
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}