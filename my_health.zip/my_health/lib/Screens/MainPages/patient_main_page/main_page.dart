import 'package:flutter/material.dart';
import 'package:my_health/Screens/MainPages/patient_main_page/components/body.dart';
import 'components/body.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'components/user.dart';
class PatientMainPage extends StatefulWidget {
  @override
  _PatientMainPageState createState() => _PatientMainPageState();
}

class _PatientMainPageState extends State<PatientMainPage> {
  DatabaseReference _ref;
  final _auth= FirebaseAuth.instance;
 var db;
  User loggedInUser;
  final listOfPatient=[];
  void getUsers() async{
    db = await FirebaseDatabase.instance.reference().child("patient");
    db.once().then((DataSnapshot snapshot){
      Map<dynamic, dynamic> values = snapshot.value;
      values.forEach((key,values) {
       listOfPatient.add(values);
      });
      print(listOfPatient);
    });
  }
@override
  void initState() {
   getCurrentUser();
   getUsers();
    super.initState();
  }
  void getCurrentUser() async{
    try{
      final user= await _auth.currentUser;
      // print(FirebaseDatabase.instance.reference().child('patient').child(user.uid));
      // final String uid= user.uid;
      if(user!=null){
        loggedInUser=user;

        // FirebaseDatabase.instance.reference().child('patient').child(uid).once().then((DataSnapshot snapshot) {
        //   patient p= patient.fromDb(snapshot);
        //  // print(p.fullName);
        // });

        //print(loggedInUser.displayName);
        //print(loggedInUser.email);
      }
    }catch(e){
      print(e);
    }

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}