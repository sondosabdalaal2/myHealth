import 'package:flutter/material.dart';
import 'package:my_health/Screens/MainPages/patient_main_page/components/body.dart';
import 'components/body.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PatientMainPage extends StatefulWidget {
  @override
  _PatientMainPageState createState() => _PatientMainPageState();
}

class _PatientMainPageState extends State<PatientMainPage> {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;
  User loggedInUser;
  String currentUser, name, e, bd, ph, pn, pp, vid;
  void getUserData(var user) async {

      final fullName = user.data()['fullName'].toString();
      final email = user.data()['email'].toString();
      final birthdate = user.data()['birthdate'].toString();
      final phone = user.data()['phone'].toString();
      final pName = user.data()['pName'].toString();
      final pPhone = user.data()['pPhone'].toString();
      final vestID = user.data()['vestID'].toString();
      final userID=user.data()['uid'].toString();
      currentUser = loggedInUser.uid;
      if (userID == currentUser) {
        setState(() {
          name = '$fullName';
          e = '$email';
          bd = '$birthdate';
          ph = '$phone';
          pn = '$pName';
          pp = '$pPhone';
          vid = '$vestID';
        });
    }
  }
  void patientsStream()async{
     await for(var snapshot in _firestore.collection('Patients').snapshots()){
      for( var user in snapshot.docs){
        getUserData(user);
      }
     }
  }

  @override
  void initState() {
    getCurrentUser();
   patientsStream();
    super.initState();
  }

  void getCurrentUser() async {
    try {
      final user = await _auth.currentUser;

      if (user != null) {
        loggedInUser = user;
      }
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(
        Name: name,
        birthdate: bd,
        pName: pn,
        pPhone: pp,
        phone: ph,
      ),
    );
  }
}
