import 'package:flutter/material.dart';
import 'recent_result.dart';
import 'background.dart';
import 'placeholder_widget.dart';
import 'package:my_health/Screens/AllResult/all_result.dart';

class Body extends StatefulWidget {
  final Name;
  final birthdate;
  final phone;
  final pName;
  final pPhone;

  Body({ this.Name,this.birthdate,this.pPhone,this.pName,this.phone});

  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  final List<Widget> _children = [
    PlaceholderWidget(RecentResult()),
    PlaceholderWidget(AllResult()),
    PlaceholderWidget(Container()),

  ];

  @override
  Widget build(BuildContext context) {
    return Background(
      phone: widget.phone,
      pPhone: widget.pPhone,
      pName: widget.pName,
      Name: widget.Name,
      birthdate: widget.birthdate,
      child:_children[_currentIndex],
      buildBottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        //backgroundColor: kPrimaryColor,
        onTap: onTabTapped, // new
        currentIndex: _currentIndex, // new
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.history_toggle_off),
              label: 'Health History',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}



