import 'package:flutter/material.dart';
import 'package:my_health/constants.dart';
import 'recent_result.dart';
import 'background.dart';
import 'placeholder_widget.dart';
import 'package:my_health/Screens/AllResult/all_result.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> {
  int _currentIndex = 0;

  void onTabTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  final List<Widget> _children = [
    PlaceholderWidget(RecentResult()),
    PlaceholderWidget(AllResult()),
    PlaceholderWidget(Container()),

  ];

  @override
  Widget build(BuildContext context) {
    return Background(
      child:_children[_currentIndex],
      buildBottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        //backgroundColor: kPrimaryColor,
        onTap: onTabTapped, // new
        currentIndex: _currentIndex, // new
        items: [
          BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.history_toggle_off),
              label: 'Health History',

          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
          // BottomNavigationBarItem(
          //     icon: SvgPicture.asset(
          //       'assets/icons/drug.svg',
          //       height: 20.0,
          //       width: 20.0,
          //     ),
          //     activeIcon: SvgPicture.asset(
          //       'assets/icons/drug.svg',
          //       height: 20.0,
          //       width: 20.0,
          //       color: Colors.white,
          //     ),
          //     label: 'Medicine',
          //     backgroundColor: Colors.green.shade900),
          // BottomNavigationBarItem(
          //     icon: SvgPicture.asset(
          //       'assets/icons/status.svg',
          //       height: 20.0,
          //       width: 20.0,
          //     ),
          //     activeIcon: SvgPicture.asset(
          //       'assets/icons/status.svg',
          //       height: 20.0,
          //       width: 20.0,
          //       color: Colors.white,
          //     ),
          //     label: 'Health Status',
          //     backgroundColor: Colors.green.shade900),
        ],
      ),
    );
  }
}



