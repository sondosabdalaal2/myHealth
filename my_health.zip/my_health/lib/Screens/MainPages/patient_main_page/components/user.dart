import 'package:firebase_database/firebase_database.dart';
class patient{
   String fullName;
   String email;
   String birthdate;
   String phoneNumber;
   String pFullName;
   String pPhoneNumber;
 patient({this.email,this.birthdate,this.fullName,this.phoneNumber,this.pFullName,this.pPhoneNumber});
  patient.fromSnapshot(DataSnapshot snapshot){
    fullName=snapshot.value['fullName'];
    email=snapshot.value["email"];
    birthdate=snapshot.value['birthdate'];
    phoneNumber=snapshot.value['phone'];
    pFullName=snapshot.value['pFullName'];
    pPhoneNumber=snapshot.value['pPhoneNumber'];

  }
   Map<String, dynamic> toJson() {
     return {
       'fullName': fullName,
       'email': email,
       'birthdate':birthdate,
       'phone':phoneNumber,
       'pFullName':pFullName,
       'pPhoneNumber':pPhoneNumber
     };
  }

}