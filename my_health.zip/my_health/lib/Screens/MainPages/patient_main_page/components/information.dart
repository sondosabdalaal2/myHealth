import 'package:flutter/material.dart';
import 'package:my_health/components/rounded_button.dart';
import 'package:my_health/Screens/Login/login_screen.dart';
import 'information_card.dart';


class Information extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          color: Colors.white,
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                SizedBox(
                  height: 20.0,
                ),
                Center(
                  child: Container(
                    margin: EdgeInsets.all(20),
                    width: 200,
                    height: 200,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                          image: AssetImage('assets/images/elderly.png'),
                          fit: BoxFit.fill),
                    ),
                  ),
                ),
                InformationCard(
                  title: 'Name',
                  subTitle: 'Sondos Abd Alaal',
                ),
                InformationCard(
                  title: 'Birthdate',
                  subTitle: '24/2/1998',
                ),
                InformationCard(
                  title: 'Phone Number',
                  subTitle: '0597164474',
                ),
                InformationCard(
                  title: 'Name of person who takes care about you',
                  subTitle: 'Manwa ',
                ),

                InformationCard(
                  title: 'Number of person who takes care about you',
                  subTitle: '0592321507',
                ),

                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: EdgeInsets.all(8.0),
                    child: RoundedButton(
                      text: 'Logout',
                      press: () {
                        //TODO: POP the information for the user
                        Navigator.push(
                          context,
                          PageRouteBuilder(
                            transitionDuration: Duration(seconds: 1),
                            transitionsBuilder: (BuildContext context,
                                Animation<double> animation,
                                Animation<double> secAnimation,
                                Widget child) {
                              animation = CurvedAnimation(
                                  parent: animation, curve: Curves.easeIn);
                              return ScaleTransition(
                                scale: animation,
                                child: child,
                                alignment: Alignment.center,
                              );
                            },
                            pageBuilder: (BuildContext context,
                                Animation<double> animation,
                                Animation<double> secAnimation) {
                              return LoginScreen();
                            },
                          ),
                        );
                      },
                    ),
                  ),
                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
}


