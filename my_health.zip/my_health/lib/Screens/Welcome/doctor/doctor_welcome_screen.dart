import 'package:flutter/material.dart';
import 'package:my_health/Screens/Welcome/doctor/components/body.dart';

class DoctorWelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
