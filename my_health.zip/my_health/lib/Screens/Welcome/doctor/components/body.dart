import 'package:flutter/material.dart';
import 'package:my_health/Screens/Login/doctor/doctor_login_screen.dart';
import 'package:my_health/Screens/Signup/doctor/doctor_form.dart';
import 'package:my_health/Screens/Welcome/doctor/components/background.dart';
import 'package:my_health/constants.dart';
import 'package:my_health/components/animation_page.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> with SingleTickerProviderStateMixin {
  AnimationController controller;
  // Animation animation;
  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
      upperBound: 100.0,
    );
    controller.forward();
    controller.addListener(() {
      setState(() {});
    });
    // print(controller.value);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return  Background(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(
                height: 50.0,
              ),
              Text(
                "My Health App",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: kFontSize,
                    color: kPrimaryColor,
                    letterSpacing: 1.0,
                    wordSpacing: 2.0),
              ),
              //SizedBox(height: size.height * 0.05),
              Image.asset(
                "assets/images/heart.png",
                height: controller.value * 3.5,
                width: controller.value * 4,
                // height: size.height * 0.45,
                // width: size.width * 2.0,
              ),
              SizedBox(height: size.height * 0.05),
              AnimationPage(
                text: 'LOGIN',
                page: DoctorLogin(),
                buttonColor: kPrimaryColor,
                textColor: Colors.white,
              ),
              AnimationPage(
                text: 'SIGNUP',
                page: DoctorForm(),
                buttonColor: kPrimaryLightColor,
                textColor: Colors.black,
              ),

            ],
          ),
        ),
      );

  }
}
