import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:my_health/Screens/Login/components/background.dart';
import 'package:my_health/Screens/Signup/signup_screen.dart';
import 'package:my_health/components/already_have_an_account_acheck.dart';
import 'package:my_health/components/rounded_button.dart';
import 'package:my_health/components/rounded_input_field.dart';
import 'package:my_health/components/rounded_password_field.dart';
//import 'package:my_health/Screens/MainPages/doctor_main_page/main_page.dart';
import 'package:my_health/Screens/MainPages/patient_main_page/main_page.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';

class Body extends StatefulWidget {
  const Body({
    Key key,
  }) : super(key: key);

  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> with SingleTickerProviderStateMixin {
  AnimationController controller;
  Animation animation;
  // Future<bool> loginUser(String phone) async{
  //   FirebaseAuth _auth= FirebaseAuth.instance;
  //   _auth.verifyPhoneNumber(
  //       phoneNumber: phone,
  //       timeout: Duration(seconds: 60),
  //       verificationCompleted: (AuthCredential credential) async{
  //        AuthResult result= await _auth.signInWithCredential(credential);
  //        FirebaseUser user= result.user;
  //       },
  //       verificationFailed: verificationFailed,
  //       codeSent: codeSent,
  //       codeAutoRetrievalTimeout: codeAutoRetrievalTimeout
  //   );
  //
  // }
  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
      upperBound: 100.0,
    );
    controller.forward();
    controller.addListener(() {
      setState(() {});
    });
    print(controller.value);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(height: size.height * 0.08),
            Image.asset(
              'assets/images/heart.png',
              height: size.height * 0.45,
              width: size.width * 2.0,
            ),
            SizedBox(height: size.height * 0.03),
            RoundedInputField(
              hintText: "Your ID Number",
              onChanged: (value) {},
            ),
            RoundedPasswordField(
              onChanged: (value) {},
            ),
            RoundedButton(
              text: "LOGIN",
              press: () {
                Navigator.push(
                  context,
                  PageRouteBuilder(
                    transitionDuration: Duration(seconds: 1),
                    transitionsBuilder: (BuildContext context,
                        Animation<double> animation,
                        Animation<double> secAnimation,
                        Widget child) {
                      animation = CurvedAnimation(
                          parent: animation, curve: Curves.easeIn);
                      return ScaleTransition(
                        scale: animation,
                        child: child,
                        alignment: Alignment.center,
                      );
                    },
                    pageBuilder: (BuildContext context,
                        Animation<double> animation,
                        Animation<double> secAnimation) {
                      return MainPage();
                    },
                  ),
                );
              },
            ),
            SizedBox(height: size.height * 0.03),
            AlreadyHaveAnAccountCheck(
              press: () {
                Navigator.push(
                  context,
                  PageRouteBuilder(
                    transitionDuration: Duration(seconds: 1),
                    transitionsBuilder: (BuildContext context,
                        Animation<double> animation,
                        Animation<double> secAnimation,
                        Widget child) {
                      animation = CurvedAnimation(
                          parent: animation, curve: Curves.easeIn);
                      return ScaleTransition(
                        scale: animation,
                        child: child,
                        alignment: Alignment.center,
                      );
                    },
                    pageBuilder: (BuildContext context,
                        Animation<double> animation,
                        Animation<double> secAnimation) {
                      return SignUpScreen();
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
