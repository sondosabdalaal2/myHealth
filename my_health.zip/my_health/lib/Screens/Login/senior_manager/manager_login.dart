import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:my_health/Screens/Login/components/background.dart';
import 'package:my_health/Screens/Signup/signup_screen.dart';
import 'package:my_health/components/already_have_an_account_acheck.dart';
import 'package:my_health/components/rounded_button.dart';
import 'package:my_health/components/rounded_input_field.dart';
import 'package:my_health/components/rounded_password_field.dart';
import 'package:my_health/Screens/MainPages/senior_main_page/main_page.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ManagerLogin extends StatefulWidget {
  const ManagerLogin({
    Key key,
  }) : super(key: key);

  @override
  _ManagerLoginState createState() => _ManagerLoginState();
}

class _ManagerLoginState extends State<ManagerLogin> with SingleTickerProviderStateMixin {
  AnimationController controller;
  Animation animation;
  final _auth = FirebaseAuth.instance;
  String _email, _password;
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
      upperBound: 100.0,
    );
    controller.forward();
    controller.addListener(() {
      setState(() {});
    });
    print(controller.value);
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Background(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: size.height * 0.08),
              Image.asset(
                'assets/images/heart.png',
                height: size.height * 0.45,
                width: size.width * 2.0,
              ),
              SizedBox(height: size.height * 0.03),
              RoundedInputField(
                hintText: "Your Email",
                onChanged: (value) {
                  _email = value;
                },
              ),
              RoundedPasswordField(
                onChanged: (value) {
                  _password = value;
                },
              ),
              RoundedButton(
                text: "LOGIN",
                press: () async {
                  try {
                    var patientType,db;
                    final logUser = await _auth.signInWithEmailAndPassword(
                        email: _email, password: _password);
                        //.then((value){
                        //  FirebaseDatabase.instance.reference().child('patient').child('type').set({'type':type});
                          // db=FirebaseDatabase.instance.reference().child("my-health-cb21b-default-rtdb").child("patient").child(FirebaseAuth.instance.currentUser.uid);
                          // db.once().then((DataSnapshot snapshot){
                          //   Map<dynamic, dynamic> values=snapshot.value;
                          //   print(values);
                          // });
                       // });
                    if (logUser != null) {


                       final currentUser= await FirebaseAuth.instance.currentUser;
                      // print('current user: ');
                      // print(currentUser);
                      // setState(() {
                      //   currentUser;
                      // });
                      // FirebaseDatabase.instance.reference().child('patient').child(path).once().then((DataSnapshot data){
                      //   print(data.value);
                      //   print(data.key);
                      //   setState(() {
                      //     patientType = data.value;
                      //   });
                      // });
                      Navigator.push(
                        context,
                        PageRouteBuilder(
                          transitionDuration: Duration(seconds: 1),
                          transitionsBuilder: (BuildContext context,
                              Animation<double> animation,
                              Animation<double> secAnimation,
                              Widget child) {
                            animation = CurvedAnimation(
                                parent: animation, curve: Curves.easeIn);
                            return ScaleTransition(
                              scale: animation,
                              child: child,
                              alignment: Alignment.center,
                            );
                          },
                          pageBuilder: (BuildContext context,
                              Animation<double> animation,
                              Animation<double> secAnimation) {
                            return ManagerMainPage();
                          },
                        ),
                      );
                    }
                  } catch (e) {
                    print(e);
                  }
                },
              ),
              SizedBox(height: size.height * 0.03),
            ],
          ),
        ),
      ),
    );
  }
}
