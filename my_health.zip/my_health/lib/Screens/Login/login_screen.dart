import 'package:flutter/material.dart';
import 'file:///C:/Users/Sondos/AndroidStudioProjects/my_health/lib/Screens/Login/patient/patient_login.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Body(),
    );
  }
}
