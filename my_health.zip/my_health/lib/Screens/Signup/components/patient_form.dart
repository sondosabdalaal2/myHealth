import 'package:flutter/material.dart';
import 'package:my_health/Screens/Login/login_screen.dart';
import 'package:my_health/Screens/Signup/components/background.dart';
import 'package:my_health/components/already_have_an_account_acheck.dart';
import 'package:my_health/components/rounded_button.dart';
import 'package:my_health/components/rounded_input_field.dart';
import 'package:my_health/components/rounded_password_field.dart';
import 'package:my_health/components/text_field_container.dart';
import 'package:my_health/constants.dart';
import 'package:intl/intl.dart';
import 'package:my_health/components/horizontal_line.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';


class PatientForm extends StatefulWidget {
  @override
  _PatientFormState createState() => _PatientFormState();
}

class _PatientFormState extends State<PatientForm> {
  final TextEditingController controller = TextEditingController();
  DateTime _birthDate;
  String _phoneNumber;
  final FirebaseAuth auth= FirebaseAuth.instance;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Background(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              SafeArea(
                child: Container(
                  color: kPrimaryColor,
                  height: 50.0,
                  width: double.infinity,
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      'Register Form',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 19.0,
                          fontStyle: FontStyle.italic,
                          wordSpacing: 2.0,
                          letterSpacing: 1.5,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
              SizedBox(height: size.height * 0.05),
              Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  children: [
                    SizedBox(
                      width: size.width * .05,
                    ),
                    Text(
                      'Information about you',
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: kPrimaryColor),
                    ),
                  ],
                ),
              ),
              HorizontalLine(
                height: 10,
              ),
              SizedBox(height: size.height * 0.03),
              RoundedInputField(
                hintText: "Full Name",
                onChanged: (value) {},
              ),
              // RoundedInputField(
              //   hintText: "ID Number",
              //   onChanged: (value) {},
              // ),
              RoundedPasswordField(
                onChanged: (value) {},
              ),
              RoundedInputField(
                hintText: "Vest ID",
                onChanged: (value) {},
                icon: Icons.vpn_key,
              ),
              RoundedInputField(
                hintText: "Address",
                icon: Icons.home,
                onChanged: (value) {},
              ),
              TextFieldContainer(
                child: TextField(
                  cursorColor: kPrimaryColor,
                  decoration: InputDecoration(
                    hintText: _birthDate == null
                        ? 'Birthday'
                        : DateFormat('dd-MM-yyyy').format(_birthDate),
                    suffixIcon: IconButton(
                        icon: Icon(
                          Icons.date_range_rounded,
                          color: kPrimaryColor,
                        ),
                        onPressed: () {
                          showDatePicker(
                            context: context,
                            initialDate: DateTime.now(), // Current Date
                            firstDate: DateTime(1900), // First date
                            lastDate: DateTime(2200), // Last Date
                            builder: (BuildContext context, Widget child) {
                              return Theme(
                                  data: ThemeData(
                                    primarySwatch:
                                        txtColor, // Color of Ok and Cancel
                                    primaryColor:
                                        kPrimaryColor, // Select date color
                                    accentColor:
                                        kPrimaryColor, // Select date color
                                  ),
                                  child: child);
                            },
                          ).then((date) {
                            setState(() {
                              _birthDate = date;
                            });
                          });
                        }),
                    border: InputBorder.none,
                  ),
                ),
              ),
              RoundedInputField(
                hintText: 'Phone Number',
                onChanged: (value) {
                  setState(() {
                   // _phoneNumber=value;
                  });

                },
                icon: Icons.phone,
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: Row(
                  children: [
                    SizedBox(
                      width: size.width * .05,
                    ),
                    Expanded(child:Text(
                      'Information about the person who takes care about you',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: kPrimaryColor),
                    ), )
                  ],
                ),
              ),
              HorizontalLine(
                height: 10,
              ),
              SizedBox(height: size.height * 0.03),
              RoundedInputField(
                hintText: "Full Name",
                icon: Icons.person,
                onChanged: (value) {},
              ),
              RoundedInputField(
                hintText: "Phone Number",
                icon: Icons.phone,
                onChanged: (value) {},
              ),
              RoundedButton(
                text: "SIGNUP",
                press: () {
                 // auth.verifyPhoneNumber(phoneNumber: _phoneNumber, verificationCompleted: verificationCompleted, verificationFailed: verificationFailed, codeSent: codeSent, codeAutoRetrievalTimeout: codeAutoRetrievalTimeout)
                },
              ),
              SizedBox(height: size.height * 0.03),
              AlreadyHaveAnAccountCheck(
                login: false,
                press: () {
                  Navigator.push(
                    context,
                    PageRouteBuilder(
                      transitionDuration: Duration(seconds: 1),
                      transitionsBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secAnimation,
                          Widget child) {
                        animation = CurvedAnimation(
                            parent: animation, curve: Curves.easeIn);
                        return ScaleTransition(
                          scale: animation,
                          child: child,
                          alignment: Alignment.center,
                        );
                      },
                      pageBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secAnimation) {
                        return LoginScreen();
                      },
                    ),
                  );
                },
              ),
              SizedBox(height: size.height * 0.03),
            ],
          ),
        ),
      ),
    );
  }
}
