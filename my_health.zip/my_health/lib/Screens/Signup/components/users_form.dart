import 'package:flutter/material.dart';
import '../doctor/doctor_form.dart';
import '../patient/patient_form.dart';
import 'forms_background.dart';
import 'package:my_health/constants.dart';
import 'package:my_health/components/animation_page.dart';

class Body extends StatefulWidget {
  @override
  _BodyState createState() => _BodyState();
}

class _BodyState extends State<Body> with SingleTickerProviderStateMixin {
  AnimationController controller;
  // Animation animation;
  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
      upperBound: 100.0,
    );
    controller.forward();
    controller.addListener(() {
      setState(() {});
    });
    // print(controller.value);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // This size provide us total height and width of our screen
    return Background(
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              "Choose One of The forms: ",
              style:
                  TextStyle(fontWeight: FontWeight.bold, fontSize: kFontSize),
            ),
            SizedBox(height: size.height * 0.05),
            SizedBox(height: size.height * 0.05),
            AnimationPage(
              text: 'Doctor',
              page: DoctorForm(),
              buttonColor: kPrimaryColor,
              textColor: Colors.white,
            ),
            AnimationPage(
              text: 'Patient',
              page: PatientForm(),
              buttonColor: kPrimaryColor,
              textColor: Colors.white,
            ),
          ],
        ),
      ),
    );
  }
}
