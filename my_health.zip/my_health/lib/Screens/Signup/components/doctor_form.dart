import 'package:flutter/material.dart';
import 'package:my_health/Screens/Login/login_screen.dart';
import 'package:my_health/Screens/Signup/components/background.dart';
import 'package:my_health/components/already_have_an_account_acheck.dart';
import 'package:my_health/components/rounded_button.dart';
import 'package:my_health/components/rounded_input_field.dart';
import 'package:my_health/components/rounded_password_field.dart';
import 'package:my_health/components/text_field_container.dart';
import 'package:my_health/constants.dart';
import 'package:intl/intl.dart';

class DoctorForm extends StatefulWidget {
  @override
  _DoctorFormState createState() => _DoctorFormState();
}

class _DoctorFormState extends State<DoctorForm> {
  final TextEditingController controller = TextEditingController();
  DateTime _birthDate;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Background(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              SafeArea(
                child: Container(
                  color: kPrimaryColor,
                  height: 50.0,
                  width: double.infinity,
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      'Register Form',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 19.0,
                          fontStyle: FontStyle.italic,
                          wordSpacing: 2.0,
                          letterSpacing: 1.5,
                          color: Colors.white),
                    ),
                  ),
                ),
              ),
              SizedBox(height: size.height * 0.03),
              RoundedInputField(
                hintText: "Full Name",
                onChanged: (value) {},

              ),
              RoundedInputField(
                hintText: "ID Number",
                onChanged: (value) {},
              ),
              RoundedPasswordField(
                onChanged: (value) {},
              ),
              RoundedInputField(
                hintText: "ID for the practicing the profession",
                onChanged: (value) {},
                icon: Icons.vpn_key,
              ),
              RoundedInputField(
                hintText: "Email",
                icon: Icons.email,
                onChanged: (value) {},
              ),
              TextFieldContainer(
                child: TextField(
                  cursorColor: kPrimaryColor,
                  decoration: InputDecoration(
                    hintText: _birthDate == null
                        ? 'Birthday'
                        : DateFormat('dd-MM-yyyy').format(_birthDate),
                    suffixIcon: IconButton(
                        icon: Icon(
                          Icons.date_range_rounded,
                          color: kPrimaryColor,
                        ),
                        onPressed: () {
                          showDatePicker(
                            context: context,
                            initialDate: DateTime.now(), // Current Date
                            firstDate: DateTime(1900), // First date
                            lastDate: DateTime(2200), // Last Date
                            builder: (BuildContext context, Widget child) {
                              return Theme(
                                  data: ThemeData(
                                    primarySwatch:
                                    txtColor, // Color of Ok and Cancel
                                    primaryColor:
                                    kPrimaryColor, // Select date color
                                    accentColor:
                                    kPrimaryColor, // Select date color
                                  ),
                                  child: child);
                            },
                          ).then((date) {
                            setState(() {
                              _birthDate = date;
                            });
                          });
                        }),
                    border: InputBorder.none,
                  ),
                ),
              ),
              RoundedInputField(
                hintText: 'Phone Number',
                onChanged: (value) {},
                icon: Icons.phone,
              ),
              RoundedButton(
                text: "SIGNUP",
                press: () {},
              ),
              SizedBox(height: size.height * 0.03),
              AlreadyHaveAnAccountCheck(
                login: false,
                press: () {
                  Navigator.push(
                    context,
                    PageRouteBuilder(
                      transitionDuration: Duration(seconds: 1),
                      transitionsBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secAnimation,
                          Widget child) {
                        animation = CurvedAnimation(
                            parent: animation, curve: Curves.easeIn);
                        return ScaleTransition(
                          scale: animation,
                          child: child,
                          alignment: Alignment.center,
                        );
                      },
                      pageBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secAnimation) {
                        return LoginScreen();
                      },
                    ),
                  );
                },
              ),
              SizedBox(height: size.height * 0.03),
            ],
          ),
        ),
      ),
    );
  }
}
