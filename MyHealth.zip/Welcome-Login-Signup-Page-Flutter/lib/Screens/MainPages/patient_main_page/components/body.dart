import 'package:flutter/material.dart';
import 'package:flutter_auth/constants.dart';
import 'package:flutter_auth/Screens/AllResult/all_result.dart';
import 'package:flutter_auth/components/rounded_button.dart';
import 'background.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Background(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Center(
            child: SizedBox(
              height: 300.0,
              width: 400.0,
              child: Card(
                shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.white70, width: 1),
                  borderRadius: BorderRadius.circular(10),
                ),
                elevation: 10.0,
                child: Expanded(child: Column(
                  //TODO:Take The Last Results
                  children: <Widget>[
                    Expanded(child:SizedBox(
                      height: 20,
                    ), ),
                    Expanded(child: Row(
                      children: <Widget>[
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          'Heart Rate: 86 bpm',
                          style:
                          TextStyle(fontSize: 16.0, color: kPrimaryColor),
                        ),
                        SizedBox(
                          width: 140,
                        ),
                        Text(
                          'SPO2: 96%',
                          style:
                          TextStyle(fontSize: 16.0, color: kPrimaryColor),
                        ),
                      ],
                    ),
                    ),

                    Expanded(child: Row(
                      children: [
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          'Temperature: 36.5',
                          style: TextStyle(
                            fontSize: 16.0,
                            color: kPrimaryColor,
                          ),
                        ),
                      ],
                    ),),
                    Expanded(child: SizedBox(
                      height: 20,
                    ),
                    ),
                    Expanded(child: Image.asset(
                      'assets/images/ecg.png',
                      height: 80.0,
                      width: double.infinity,
                    ), ),

                    SizedBox(
                      height: 80,
                    ),
                    Row(
                      children: <Widget>[
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          'Time: 7:00 pm',
                          style:
                          TextStyle(fontSize: 16.0, color: kPrimaryColor),
                        ),
                        SizedBox(
                          width: 140,
                        ),
                        Text(
                          'Date: 28/3/2021',
                          style:
                          TextStyle(fontSize: 16.0, color: kPrimaryColor),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        SizedBox(
                          width: 20,
                        ),
                        Text(
                          //TODO: Decide the results status
                          'Status: Normal/abnormal',
                          style: TextStyle(
                            fontSize: 16.0,
                            color: kPrimaryColor,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                ),
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: RoundedButton(
                text: 'ALL RESULT',
                textColor: Colors.white,
                press: () {
                  Navigator.push(
                    context,
                    PageRouteBuilder(
                      transitionDuration: Duration(seconds: 1),
                      transitionsBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secAnimation,
                          Widget child) {
                        animation = CurvedAnimation(
                            parent: animation, curve: Curves.easeIn);
                        return ScaleTransition(
                          scale: animation,
                          child: child,
                          alignment: Alignment.center,
                        );
                      },
                      pageBuilder: (BuildContext context,
                          Animation<double> animation,
                          Animation<double> secAnimation) {
                        return AllResult();
                      },
                    ),
                  );
                },
              ),
            ),
          )
        ],
      ),
    );
  }
}
